---
name: PaperShelf Expressive
colors:
  surface: '#fcf9f5'
  surface-dim: '#dcdad6'
  surface-bright: '#fcf9f5'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f6f3ef'
  surface-container: '#f0ede9'
  surface-container-high: '#eae8e4'
  surface-container-highest: '#e5e2de'
  on-surface: '#1c1c1a'
  on-surface-variant: '#474551'
  inverse-surface: '#31302e'
  inverse-on-surface: '#f3f0ec'
  outline: '#787582'
  outline-variant: '#c8c4d3'
  surface-tint: '#5b53aa'
  primary: '#261a74'
  on-primary: '#ffffff'
  primary-container: '#3d348b'
  on-primary-container: '#aba3ff'
  inverse-primary: '#c6c0ff'
  secondary: '#8f4e00'
  on-secondary: '#ffffff'
  secondary-container: '#fc9013'
  on-secondary-container: '#623400'
  tertiary: '#150d90'
  on-tertiary: '#ffffff'
  tertiary-container: '#302fa5'
  on-tertiary-container: '#a4a5ff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e4dfff'
  primary-fixed-dim: '#c6c0ff'
  on-primary-fixed: '#150066'
  on-primary-fixed-variant: '#433a91'
  secondary-fixed: '#ffdcc2'
  secondary-fixed-dim: '#ffb77a'
  on-secondary-fixed: '#2e1500'
  on-secondary-fixed-variant: '#6d3a00'
  tertiary-fixed: '#e1dfff'
  tertiary-fixed-dim: '#c1c1ff'
  on-tertiary-fixed: '#08006c'
  on-tertiary-fixed-variant: '#3635aa'
  background: '#fcf9f5'
  on-background: '#1c1c1a'
  surface-variant: '#e5e2de'
  vibrant-yellow: '#f7b801'
  deep-orange: '#f35b04'
  ink-black: '#1a1a1a'
  washi-tape-green: '#a3b18a'
  paper-shadow: rgba(61, 52, 139, 0.15)
typography:
  headline-xl:
    fontFamily: Courier Prime
    fontSize: 48px
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Courier Prime
    fontSize: 32px
    fontWeight: '700'
    lineHeight: '1.2'
  headline-lg-mobile:
    fontFamily: Courier Prime
    fontSize: 28px
    fontWeight: '700'
    lineHeight: '1.2'
  body-lg:
    fontFamily: Quicksand
    fontSize: 18px
    fontWeight: '500'
    lineHeight: '1.6'
  body-md:
    fontFamily: Quicksand
    fontSize: 16px
    fontWeight: '500'
    lineHeight: '1.5'
  label-caps:
    fontFamily: Space Mono
    fontSize: 12px
    fontWeight: '700'
    lineHeight: '1'
    letterSpacing: 0.1em
  caption-hand:
    fontFamily: Quicksand
    fontSize: 14px
    fontWeight: '600'
    lineHeight: '1.4'
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 8px
  margin-page: 32px
  gutter: 24px
  sketch-offset: 4px
---

## Brand & Style
This design system transforms a digital utility into a tactile, creative sanctuary. The brand personality is **whimsical, energetic, and unapologetically expressive**, moving away from sterile "productivity" and toward the "creative mess" of a well-loved physical notebook. It targets creators, students, and thinkers who find inspiration in the physical act of scrapbooking.

The design style is a hybrid of **Neobrutalism** and **Tactile Scrapbooking**. It utilizes chunky, high-contrast elements, thick "ink" borders, and irregular shapes that mimic hand-cut paper. The interface should feel "built" rather than "rendered," featuring textures that suggest varied paper stocks and interactive elements that behave like physical objects.

## Colors
The "Colorful Daybreak" palette is applied with maximum vibrance. Instead of subtle accents, colors are used to categorize entire sections of the notebook, creating a high-contrast, color-coded navigation experience.

The `neutral_color_hex` is a warm, slightly off-white "cream" base that mimics recycled paper. `ink-black` is used for all borders and sketchy details to maintain a hand-drawn feel. Each "paper section" (e.g., Projects, Notes, Archives) should adopt one of the primary, secondary, or tertiary colors as its dominant theme, used for headers, chunky shadows, and active states.

## Typography
The typography system balances the rigid, mechanical feel of a typewriter with the soft, friendly nature of a modern notebook. 

- **Headlines:** Use **Courier Prime** for a distinctive typewriter aesthetic. These should be treated like stamped or typed titles, occasionally slightly rotated (1-2 degrees) for a manual look.
- **Body:** Use **Quicksand** for high legibility with a soft, rounded personality that complements the "wonky" shapes.
- **Metadata/Labels:** **Space Mono** provides a technical, "cataloged" feel, like small labels printed on a Dymo embosser or found in the margins of a ledger.

## Layout & Spacing
This design system uses a **Fluid Grid** that behaves like a loose scrapbook assembly. While the underlying structure is organized into a 12-column layout, individual elements should feel slightly "off-center."

Spacing follows an 8px rhythm, but visual interest is added through "sketch-offsets"—where borders or decorative elements are shifted 4px away from their parent container to create a layered, collage-like effect. Margin areas on desktop are intentionally wide to allow for "overflow" decorations like washi tape, digital stickers, or hand-drawn marginalia.

## Elevation & Depth
In this design system, depth is achieved through **physical layering** rather than realistic lighting:

- **Tonal Stacking:** Higher elevation is shown by adding more "paper layers" underneath an object, visible as multiple staggered borders.
- **Neobrutalist Shadows:** Use hard, 100% opacity offsets in the section's accent color. For example, a card in the "Projects" section (using `#3d348b`) will have a hard shadow of the same color, offset by 6px to the bottom-right.
- **Washi Tape:** Semi-transparent overlays (using `washi-tape-green`) "pin" cards to the background, creating a zero-depth but high-tactile visual cue.
- **Subtle Texture:** A low-opacity grain or "paper fiber" SVG filter should be applied to the main background and all primary surfaces to break up flat digital colors.

## Shapes
Shapes are intentionally imperfect. While the base `roundedness` is set to 2 (0.5rem), this should be implemented using a "wonky" border-radius logic where each corner has a slightly different value (e.g., `12px 8px 15px 10px`) to mimic hand-cutting.

Borders should be 2px or 3px thick `ink-black` and can utilize a `rough` or `sketchy` stroke effect if the platform supports it. Decorative elements like "torn edges" should be used on the bottom of list items or the tops of cards to reinforce the paper shelf metaphor.